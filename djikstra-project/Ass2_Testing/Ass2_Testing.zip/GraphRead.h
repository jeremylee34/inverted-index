// Function to read in a graph
// COMP2521 Assignment 2

#include <stdbool.h>
#include "Graph.h"

#ifndef _CS2521_GRAPHREAD_H
#define _CS2521_GRAPHREAD_H

Graph readGraph(char *file); 

#endif

